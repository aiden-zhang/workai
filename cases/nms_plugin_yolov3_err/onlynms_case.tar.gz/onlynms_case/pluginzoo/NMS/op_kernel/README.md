# DLI plugin

## Description

Included are the sources for DLI plugins  and sample applications demonstrating usage

## Contents

Steps to compile dlnne_plugin:
	1, source your python environment,for example: source /usr/python/penv3.6.8/bin/activate 
	2, activate sdk environment,for example: . usr/sdk/env.sh
	3, export SDK_DIR={your sdk dir}, for example: export SDK_DIR=/usr/sdk
	4, mkdir {your own folder name},level with dlnne_plugin,for example: mkdir dlnne_plugin_build
	5, cd {your own folder name},and cmake ../dlnne_plugin, then make
