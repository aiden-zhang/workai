#ifndef __KERNEL_H__
#define __KERNEL_H__
#include "utils.h"

extern char combine_src_file[];
extern char cusm_src_file[];
extern char filter_sort_src_file[];
extern char gather_boxes_src_file[];
extern char non_max_suppression_src_file[];
extern char yolov3_box_src_file[];




#endif //end __KERNEL_H__