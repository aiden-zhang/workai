#ifndef __DL_DLNMS_PLUGIN_H__
#define __DL_DLNMS_PLUGIN_H__


#ifdef __cplusplus 
extern "C"{
#endif

void initPluginRegister();

#ifdef __cplusplus
}
#endif

#endif //__DL_DLNMS_PLUGIN_H__