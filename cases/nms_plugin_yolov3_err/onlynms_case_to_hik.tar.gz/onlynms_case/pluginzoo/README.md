source env
------------
source python 、 SDK env

export SDK_DIR
--------------
export SDK_DIR="sdk path"

Compile the plugin library
--------------
./build_all.sh

unit test
-------------
Refer to separate plugin operator ....